const user = {
  name: "Алдияр",
  age: 14,
  city: "Алматы"
};

localStorage.setItem("userData", JSON.stringify(user));

const storedUserData = localStorage.getItem("userData");
const parsedUser = JSON.parse(storedUserData);

const userInfo = document.getElementById("user-info");
userInfo.textContent = "Имя: " + parsedUser.name + ", Город: " + parsedUser.city;