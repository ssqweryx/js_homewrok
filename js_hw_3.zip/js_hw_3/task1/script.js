const usernameInput = document.getElementById("username");
const themeSelect = document.getElementById("theme");
const saveBtn = document.getElementById("save-btn");
const resetBtn = document.getElementById("reset-btn");
const output = document.getElementById("output");

function displayData() {
  const savedName = localStorage.getItem("username");
  const savedTheme = localStorage.getItem("theme");

  if (savedName || savedTheme) {
    output.textContent = "Имя: " + (savedName || "—") + ", Тема: " + (savedTheme || "—");
  } else {
    output.textContent = "Данные отсутствуют";
  }
}

displayData();

saveBtn.addEventListener("click", function() {
  localStorage.setItem("username", usernameInput.value);
  localStorage.setItem("theme", themeSelect.value);
  displayData();
});

resetBtn.addEventListener("click", function() {
  localStorage.removeItem("username");
  localStorage.removeItem("theme");
  usernameInput.value = "";
  themeSelect.value = "light";
  displayData();
});