const defaultStudents = [
  { name: "Алекс", age: 16 },
  { name: "Елена", age: 17 },
  { name: "Иван", age: 15 }
];

const list = document.getElementById("students-list");
const addBtn = document.getElementById("add-btn");
const clearBtn = document.getElementById("clear-btn");
const nameInput = document.getElementById("student-name");
const ageInput = document.getElementById("student-age");

function getStudents() {
  const saved = localStorage.getItem("students");
  if (saved) {
    return JSON.parse(saved);
  } else {
    localStorage.setItem("students", JSON.stringify(defaultStudents));
    return defaultStudents;
  }
}

function render() {
  list.innerHTML = "";
  const students = getStudents();
  students.forEach(function(student) {
    const li = document.createElement("li");
    li.textContent = student.name + " (" + student.age + " лет)";
    list.appendChild(li);
  });
}

render();

addBtn.addEventListener("click", function() {
  const name = nameInput.value.trim();
  const age = Number(ageInput.value);

  if (name && age) {
    const students = getStudents();
    students.push({ name: name, age: age });
    localStorage.setItem("students", JSON.stringify(students));
    nameInput.value = "";
    ageInput.value = "";
    render();
  }
});

clearBtn.addEventListener("click", function() {
  localStorage.removeItem("students");
  list.innerHTML = "";
});