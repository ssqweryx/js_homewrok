const usersData = {
    "1": {
        name: "Алексей Смирнов",
        city: "Москва",
        job: "Frontend-разработчик",
        interests: "Программирование, шахматы, бег"
    },
    "2": {
        name: "Елена Васильева",
        city: "Санкт-Петербург",
        job: "Дизайнер",
        interests: "Живопись, фотография, йога"
    },
    "3": {
        name: "Дмитрий Иванов",
        city: "Казань",
        job: "Маркетолог",
        interests: "Книги, путешествия, гитара"
    }
};

const modal = document.getElementById('modal');
const modalName = document.getElementById('modalName');
const modalCity = document.getElementById('modalCity');
const modalJob = document.getElementById('modalJob');
const modalInterests = document.getElementById('modalInterests');
const closeModalBtn = document.getElementById('closeModalBtn');
const closeXBtn = document.querySelector('.close-x');
const modalBackdrop = document.querySelector('.modal-backdrop');
const cardsContainer = document.querySelector('.cards-grid');

cardsContainer.addEventListener('click', function(event) {
    if (event.target.classList.contains('details-btn')) {
        const userId = event.target.dataset.id;
        const user = usersData[userId];

        if (user) {
            modalName.textContent = user.name;
            modalCity.textContent = user.city;
            modalJob.textContent = user.job;
            modalInterests.textContent = user.interests;
            modal.classList.remove('hidden');
        }
    }
});

function closeModal() {
    modal.classList.add('hidden');
}

closeModalBtn.addEventListener('click', closeModal);
closeXBtn.addEventListener('click', closeModal);
modalBackdrop.addEventListener('click', closeModal);

document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape' && !modal.classList.contains('hidden')) {
        closeModal();
    }
});