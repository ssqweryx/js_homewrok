const guessInput = document.getElementById('guessInput');
const checkBtn = document.getElementById('checkBtn');
const restartBtn = document.getElementById('restartBtn');
const message = document.getElementById('message');
const attemptsCount = document.getElementById('attemptsCount');

let targetNumber;
let attempts;

function initGame() {
    targetNumber = Math.floor(Math.random() * 100) + 1;
    attempts = 0;
    attemptsCount.textContent = attempts;
    message.textContent = '';
    guessInput.value = '';
    guessInput.disabled = false;
    checkBtn.disabled = false;
    restartBtn.classList.add('hidden');
}

function checkGuess() {
    const userGuess = Number(guessInput.value);

    if (!userGuess || userGuess < 1 || userGuess > 100) {
        message.textContent = 'Введите число от 1 до 100!';
        return;
    }

    attempts++;
    attemptsCount.textContent = attempts;

    if (userGuess === targetNumber) {
        message.textContent = 'Вы угадали!';
        guessInput.disabled = true;
        checkBtn.disabled = true;
        restartBtn.classList.remove('hidden');
    } else if (userGuess > targetNumber) {
        message.textContent = 'Загаданное число меньше';
    } else {
        message.textContent = 'Загаданное число больше';
    }

    guessInput.value = '';
    guessInput.focus();
}

checkBtn.addEventListener('click', checkGuess);

guessInput.addEventListener('keydown', function(event) {
    if (event.key === 'Enter') {
        checkGuess();
    }
});

restartBtn.addEventListener('click', initGame);

initGame();