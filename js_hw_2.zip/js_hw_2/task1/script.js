const card = document.getElementById("card");
const cardText = document.getElementById("card-text");

card.addEventListener("click", function() {
  cardText.textContent = "Clicked!";
});

card.addEventListener("dblclick", function() {
  cardText.textContent = "Double click!";
});

card.addEventListener("mouseenter", function() {
  card.classList.add("active");
});

card.addEventListener("mouseleave", function() {
  card.classList.remove("active");
});