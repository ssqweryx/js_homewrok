const form = document.getElementById("reg-form");
const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");
const status = document.getElementById("status");

form.addEventListener("submit", function(event) {
  event.preventDefault();

  if (nameInput.value.trim() === "" || emailInput.value.trim() === "") {
    alert("Заполните все поля!");
  } else {
    status.textContent = "Registration successful!";
  }
});