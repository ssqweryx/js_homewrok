const card = document.getElementById("card");
const cardText = document.getElementById("card-text");
const controls = document.getElementById("controls");

const stateNames = {
  calm: "Спокойно",
  warning: "Внимание",
  stop: "Стоп"
};

function resetCard() {
  card.className = "card initial";
  cardText.textContent = "Начальное состояние";
}

controls.addEventListener("click", function(event) {
  if (event.target.tagName === "BUTTON") {
    const state = event.target.dataset.state;
    card.className = "card " + state;
    cardText.textContent = stateNames[state];
  }
});

card.addEventListener("dblclick", function() {
  resetCard();
});

card.addEventListener("contextmenu", function(event) {
  event.preventDefault();
  card.className = "card custom-bg";
});

document.addEventListener("keydown", function(event) {
  if (event.key === "Escape") {
    resetCard();
  }
});