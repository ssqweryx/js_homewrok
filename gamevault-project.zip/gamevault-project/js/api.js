const API_URL = "https://www.freetogame.com/api/games";
const PROXY_URL = `https://api.allorigins.win/raw?url=${encodeURIComponent(API_URL)}`;

const FALLBACK_GAMES = [
  {
    id: 540,
    title: "Overwatch 2",
    thumbnail: "https://www.freetogame.com/g/540/thumbnail.jpg",
    short_description: "Командный шутер от первого лица с уникальными героями и динамичными сражениями 5 на 5.",
    game_url: "https://www.freetogame.com/open/overwatch-2",
    genre: "Shooter",
    platform: "PC (Windows)",
    publisher: "Activision Blizzard",
    developer: "Blizzard Entertainment",
    release_date: "2022-10-04"
  },
  {
    id: 521,
    title: "Diablo Immortal",
    thumbnail: "https://www.freetogame.com/g/521/thumbnail.jpg",
    short_description: "Мрачная экшен-RPG во вселенной Санктуария с подземельями и кооперативными рейдами.",
    game_url: "https://www.freetogame.com/open/diablo-immortal",
    genre: "MMOARPG",
    platform: "PC (Windows)",
    publisher: "Blizzard Entertainment",
    developer: "Blizzard Entertainment",
    release_date: "2022-06-02"
  },
  {
    id: 516,
    title: "PUBG: BATTLEGROUNDS",
    thumbnail: "https://www.freetogame.com/g/516/thumbnail.jpg",
    short_description: "Классическая королевская битва на 100 игроков с реалистичной баллистикой и тактикой.",
    game_url: "https://www.freetogame.com/open/pubg",
    genre: "Shooter",
    platform: "PC (Windows)",
    publisher: "KRAFTON, Inc.",
    developer: "KRAFTON, Inc.",
    release_date: "2022-01-12"
  },
  {
    id: 475,
    title: "Genshin Impact",
    thumbnail: "https://www.freetogame.com/g/475/thumbnail.jpg",
    short_description: "Приключенческая RPG с открытым миром Тейвата и боевой системой на основе стихий.",
    game_url: "https://www.freetogame.com/open/genshin-impact",
    genre: "Action RPG",
    platform: "PC (Windows)",
    publisher: "miHoYo",
    developer: "miHoYo",
    release_date: "2020-09-28"
  },
  {
    id: 452,
    title: "Call Of Duty: Warzone",
    thumbnail: "https://www.freetogame.com/g/452/thumbnail.jpg",
    short_description: "Масштабная королевская битва во вселенной Modern Warfare с контрактами и ГУЛАГом.",
    game_url: "https://www.freetogame.com/open/call-of-duty-warzone",
    genre: "Shooter",
    platform: "PC (Windows)",
    publisher: "Activision",
    developer: "Infinity Ward",
    release_date: "2020-03-10"
  },
  {
    id: 345,
    title: "Forge of Empires",
    thumbnail: "https://www.freetogame.com/g/345/thumbnail.jpg",
    short_description: "Браузерная градостроительная стратегия с развитием цивилизации сквозь исторические эпохи.",
    game_url: "https://www.freetogame.com/open/forge-of-empires",
    genre: "Strategy",
    platform: "Web Browser",
    publisher: "InnoGames",
    developer: "InnoGames",
    release_date: "2012-04-17"
  }
];

export async function fetchGames() {
  try {
    const response = await fetch(PROXY_URL);
    if (!response.ok) {
      throw new Error("API error");
    }
    const data = await response.json();
    return Array.isArray(data) && data.length > 0 ? data.slice(0, 60) : FALLBACK_GAMES;
  } catch (error) {
    return FALLBACK_GAMES;
  }
}
