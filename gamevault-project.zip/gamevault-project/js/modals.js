export function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.remove("hidden");
  }
}

export function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add("hidden");
  }
}

export function initModalClosers() {
  document.addEventListener("click", (event) => {
    const targetId = event.target.getAttribute("data-close");
    if (targetId) {
      closeModal(targetId);
    }
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      document.querySelectorAll(".modal").forEach((m) => m.classList.add("hidden"));
    }
  });
}

export function renderGameDetails(game, isFavorite) {
  const container = document.getElementById("detailContent");
  container.innerHTML = `
    <img src="${game.thumbnail}" alt="${game.title}" class="detail-banner">
    <div class="detail-header">
      <div>
        <h2>${game.title}</h2>
        <span class="badge">${game.genre}</span>
      </div>
      <button id="modalFavBtn" class="btn btn-fav ${isFavorite ? "active" : ""}" data-id="${game.id}">
        ${isFavorite ? "★ В избранном" : "☆ В избранное"}
      </button>
    </div>
    <p>${game.short_description}</p>
    <div class="detail-grid">
      <div><span>Платформа</span>${game.platform}</div>
      <div><span>Дата выхода</span>${game.release_date}</div>
      <div><span>Разработчик</span>${game.developer}</div>
      <div><span>Издатель</span>${game.publisher}</div>
    </div>
    <a href="${game.game_url}" target="_blank" rel="noopener noreferrer" class="btn btn-primary full-width" style="display:inline-block;text-align:center;text-decoration:none;">
      Перейти на страницу игры
    </a>
  `;
  openModal("detailModal");
}
