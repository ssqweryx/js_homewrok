import { fetchGames } from "./api.js";
import { getCurrentUser, registerUser, loginUser, logoutUser, toggleUserFavorite } from "./auth.js";
import { extractGenres, filterAndSortGames } from "./filters.js";
import { openModal, closeModal, initModalClosers, renderGameDetails } from "./modals.js";
import { renderUserPanel, renderGenreOptions, renderGamesList } from "./ui.js";

const state = {
  games: [],
  user: getCurrentUser(),
  search: "",
  genre: "all",
  platform: "all",
  sort: "default",
  onlyFavorites: false,
  authMode: "login",
  selectedGame: null
};

function getFavoriteIds() {
  return state.user && Array.isArray(state.user.favorites) ? state.user.favorites : [];
}

function updateFavoritesCounter() {
  document.getElementById("favCount").textContent = getFavoriteIds().length;
}

function updateView() {
  const filtered = filterAndSortGames(state.games, {
    search: state.search,
    genre: state.genre,
    platform: state.platform,
    sort: state.sort,
    onlyFavorites: state.onlyFavorites,
    favoriteIds: getFavoriteIds()
  });

  renderGamesList(filtered, getFavoriteIds(), handleOpenDetails, handleToggleFavorite);
  updateFavoritesCounter();
}

function syncUserUI() {
  renderUserPanel(
    state.user,
    () => openModal("authModal"),
    () => {
      logoutUser();
      state.user = null;
      state.onlyFavorites = false;
      document.getElementById("favoritesToggleBtn").classList.remove("active");
      syncUserUI();
      updateView();
    }
  );
  updateFavoritesCounter();
}

function handleToggleFavorite(gameId) {
  if (!state.user) {
    openModal("authModal");
    return;
  }

  const updatedFavs = toggleUserFavorite(gameId);
  if (updatedFavs) {
    state.user.favorites = updatedFavs;
    updateView();
    if (state.selectedGame && state.selectedGame.id === gameId) {
      renderGameDetails(state.selectedGame, updatedFavs.includes(gameId));
      bindModalFavButton();
    }
  }
}

function bindModalFavButton() {
  const btn = document.getElementById("modalFavBtn");
  if (btn) {
    btn.addEventListener("click", () => {
      const id = Number(btn.getAttribute("data-id"));
      handleToggleFavorite(id);
    });
  }
}

function handleOpenDetails(game) {
  state.selectedGame = game;
  const isFav = getFavoriteIds().includes(game.id);
  renderGameDetails(game, isFav);
  bindModalFavButton();
}

function setupAuthForm() {
  const tabLogin = document.getElementById("tabLogin");
  const tabRegister = document.getElementById("tabRegister");
  const nameGroup = document.getElementById("nameFieldGroup");
  const submitBtn = document.getElementById("authSubmitBtn");
  const authForm = document.getElementById("authForm");
  const authError = document.getElementById("authError");

  function switchMode(mode) {
    state.authMode = mode;
    authError.textContent = "";
    if (mode === "register") {
      tabRegister.classList.add("active");
      tabLogin.classList.remove("active");
      nameGroup.classList.remove("hidden");
      submitBtn.textContent = "Зарегистрироваться";
    } else {
      tabLogin.classList.add("active");
      tabRegister.classList.remove("active");
      nameGroup.classList.add("hidden");
      submitBtn.textContent = "Войти";
    }
  }

  tabLogin.addEventListener("click", () => switchMode("login"));
  tabRegister.addEventListener("click", () => switchMode("register"));

  authForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const name = document.getElementById("authName").value;
    const email = document.getElementById("authEmail").value;
    const password = document.getElementById("authPassword").value;

    const result = state.authMode === "register"
      ? registerUser(name, email, password)
      : loginUser(email, password);

    if (!result.ok) {
      authError.textContent = result.message;
      return;
    }

    state.user = result.user;
    authForm.reset();
    authError.textContent = "";
    closeModal("authModal");
    syncUserUI();
    updateView();
  });
}

function setupControls() {
  document.getElementById("searchInput").addEventListener("input", (e) => {
    state.search = e.target.value;
    updateView();
  });

  document.getElementById("genreFilter").addEventListener("change", (e) => {
    state.genre = e.target.value;
    updateView();
  });

  document.getElementById("platformFilter").addEventListener("change", (e) => {
    state.platform = e.target.value;
    updateView();
  });

  document.getElementById("sortSelect").addEventListener("change", (e) => {
    state.sort = e.target.value;
    updateView();
  });

  const favToggleBtn = document.getElementById("favoritesToggleBtn");
  favToggleBtn.addEventListener("click", () => {
    if (!state.user) {
      openModal("authModal");
      return;
    }
    state.onlyFavorites = !state.onlyFavorites;
    favToggleBtn.classList.toggle("active", state.onlyFavorites);
    updateView();
  });
}

async function init() {
  initModalClosers();
  setupAuthForm();
  setupControls();
  syncUserUI();

  state.games = await fetchGames();
  const genres = extractGenres(state.games);
  renderGenreOptions(genres);
  updateView();
}

init();
