const USERS_KEY = "gamevault_users";
const SESSION_KEY = "gamevault_current_user";

function getUsers() {
  return JSON.parse(localStorage.getItem(USERS_KEY)) || [];
}

function saveUsers(users) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

export function getCurrentUser() {
  return JSON.parse(localStorage.getItem(SESSION_KEY)) || null;
}

export function registerUser(name, email, password) {
  const cleanName = name.trim();
  const cleanEmail = email.trim().toLowerCase();

  if (cleanName.length < 2) {
    return { ok: false, message: "Имя должно содержать минимум 2 символа" };
  }
  if (password.length < 4) {
    return { ok: false, message: "Пароль должен содержать минимум 4 символа" };
  }

  const users = getUsers();
  const exists = users.some((u) => u.email === cleanEmail);
  if (exists) {
    return { ok: false, message: "Пользователь с таким email уже существует" };
  }

  const newUser = {
    id: Date.now(),
    name: cleanName,
    email: cleanEmail,
    password,
    favorites: []
  };

  users.push(newUser);
  saveUsers(users);
  localStorage.setItem(SESSION_KEY, JSON.stringify(newUser));
  return { ok: true, user: newUser };
}

export function loginUser(email, password) {
  const cleanEmail = email.trim().toLowerCase();
  const users = getUsers();
  const user = users.find((u) => u.email === cleanEmail && u.password === password);

  if (!user) {
    return { ok: false, message: "Неверный email или пароль" };
  }

  localStorage.setItem(SESSION_KEY, JSON.stringify(user));
  return { ok: true, user };
}

export function logoutUser() {
  localStorage.removeItem(SESSION_KEY);
}

export function toggleUserFavorite(gameId) {
  const current = getCurrentUser();
  if (!current) return null;

  const users = getUsers();
  const index = users.findIndex((u) => u.id === current.id);
  if (index === -1) return null;

  const favs = users[index].favorites || [];
  const exists = favs.includes(gameId);

  users[index].favorites = exists
    ? favs.filter((id) => id !== gameId)
    : [...favs, gameId];

  saveUsers(users);
  localStorage.setItem(SESSION_KEY, JSON.stringify(users[index]));
  return users[index].favorites;
}
