export function extractGenres(games) {
  const unique = new Set(games.map((g) => g.genre).filter(Boolean));
  return Array.from(unique).sort();
}

export function filterAndSortGames(games, options) {
  const { search, genre, platform, sort, onlyFavorites, favoriteIds } = options;
  const query = search.trim().toLowerCase();

  let result = games.filter((game) => {
    const matchesSearch = game.title.toLowerCase().includes(query);
    const matchesGenre = genre === "all" || game.genre === genre;
    const matchesPlatform = platform === "all" || game.platform.includes(platform);
    const matchesFav = !onlyFavorites || favoriteIds.includes(game.id);
    return matchesSearch && matchesGenre && matchesPlatform && matchesFav;
  });

  if (sort === "title-asc") {
    result.sort((a, b) => a.title.localeCompare(b.title));
  } else if (sort === "title-desc") {
    result.sort((a, b) => b.title.localeCompare(a.title));
  } else if (sort === "date-desc") {
    result.sort((a, b) => new Date(b.release_date) - new Date(a.release_date));
  } else if (sort === "date-asc") {
    result.sort((a, b) => new Date(a.release_date) - new Date(b.release_date));
  }

  return result;
}
