export function renderUserPanel(user, onOpenAuth, onLogout) {
  const container = document.getElementById("userControls");

  if (!user) {
    container.innerHTML = `<button id="loginOpenBtn" class="btn btn-primary">Войти</button>`;
    document.getElementById("loginOpenBtn").addEventListener("click", onOpenAuth);
    return;
  }

  container.innerHTML = `
    <span class="user-badge">${user.name}</span>
    <button id="logoutBtn" class="btn btn-danger">Выйти</button>
  `;
  document.getElementById("logoutBtn").addEventListener("click", onLogout);
}

export function renderGenreOptions(genres) {
  const select = document.getElementById("genreFilter");
  genres.forEach((genre) => {
    const option = document.createElement("option");
    option.value = genre;
    option.textContent = genre;
    select.appendChild(option);
  });
}

export function renderGamesList(games, favoriteIds, onSelectGame, onToggleFavorite) {
  const grid = document.getElementById("gamesGrid");
  const status = document.getElementById("statusMessage");

  grid.innerHTML = "";

  if (games.length === 0) {
    status.textContent = "Игры по выбранным параметрам не найдены.";
    status.classList.remove("hidden");
    return;
  }

  status.classList.add("hidden");

  games.forEach((game) => {
    const isFav = favoriteIds.includes(game.id);
    const card = document.createElement("article");
    card.className = "game-card";
    card.innerHTML = `
      <img src="${game.thumbnail}" alt="${game.title}" class="game-thumb" loading="lazy">
      <div class="game-body">
        <div class="game-meta">
          <span class="badge">${game.genre}</span>
          <span>${game.release_date}</span>
        </div>
        <h3 class="game-title">${game.title}</h3>
        <p class="game-desc">${game.short_description}</p>
        <div class="card-actions">
          <button class="btn btn-outline btn-details">Подробнее</button>
          <button class="btn btn-fav ${isFav ? "active" : ""}" title="В избранное">
            ${isFav ? "★" : "☆"}
          </button>
        </div>
      </div>
    `;

    card.querySelector(".btn-details").addEventListener("click", () => onSelectGame(game));
    card.querySelector(".btn-fav").addEventListener("click", () => onToggleFavorite(game.id));

    grid.appendChild(card);
  });
}
