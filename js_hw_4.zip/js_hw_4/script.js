const loadBtn = document.getElementById("loadBtn");
const searchInput = document.getElementById("searchInput");
const statusMessage = document.getElementById("statusMessage");
const userList = document.getElementById("userList");

let allUsers = [];

async function loadUsers() {
  userList.innerHTML = "";
  statusMessage.textContent = "Loading...";
  statusMessage.className = "status-message loading";

  try {
    const response = await fetch("https://jsonplaceholder.typicode.com/users");

    if (!response.ok) {
      throw new Error("Ошибка сети");
    }

    allUsers = await response.json();

    statusMessage.textContent = "";
    searchInput.disabled = false;

    renderUsers(allUsers);
  } catch (error) {
    statusMessage.textContent = "Ошибка загрузки данных";
    statusMessage.className = "status-message error";
    console.error(error);
  }
}

function renderUsers(users) {
  userList.innerHTML = "";

  if (users.length === 0) {
    userList.innerHTML = "<p>Пользователи не найдены</p>";
    return;
  }

  users.forEach(user => {
    const card = document.createElement("div");
    card.className = "user-card";

    card.innerHTML = `
      <h3>${user.name}</h3>
      <p><strong>Email:</strong> ${user.email}</p>
      <p><strong>Телефон:</strong> ${user.phone}</p>
    `;

    userList.appendChild(card);
  });
}

function handleSearch(event) {
  const searchTerm = event.target.value.toLowerCase();
  
  const filteredUsers = allUsers.filter(user => 
    user.name.toLowerCase().includes(searchTerm)
  );

  renderUsers(filteredUsers);
}

loadBtn.addEventListener("click", loadUsers);
searchInput.addEventListener("input", handleSearch);