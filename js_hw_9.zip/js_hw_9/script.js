let wishes = JSON.parse(localStorage.getItem('wishes')) || [];

const nameInput = document.getElementById('nameInput');
const priceInput = document.getElementById('priceInput');
const addBtn = document.getElementById('addBtn');
const errorMsg = document.getElementById('errorMsg');
const wishList = document.getElementById('wishList');
const totalCount = document.getElementById('totalCount');

function saveWishes() {
    localStorage.setItem('wishes', JSON.stringify(wishes));
}

function renderWishes() {
    wishList.innerHTML = '';

    if (wishes.length === 0) {
        wishList.innerHTML = '<li class="empty-message">Список желаний пуст</li>';
        totalCount.textContent = '0';
        return;
    }

    totalCount.textContent = wishes.length;

    wishes.forEach(wish => {
        const li = document.createElement('li');
        li.className = `wish-item ${wish.isPurchased ? 'purchased' : ''}`;
        
        li.innerHTML = `
            <div class="wish-info">
                <span class="wish-name">${escapeHtml(wish.name)}</span>
                <span class="wish-price">${Number(wish.price).toLocaleString()} ₸</span>
            </div>
            <div class="wish-actions">
                <button class="toggle-btn" data-id="${wish.id}">${wish.isPurchased ? 'Отменить' : 'Куплено'}</button>
                <button class="delete-btn" data-id="${wish.id}">Удалить</button>
            </div>
        `;
        
        wishList.appendChild(li);
    });
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function addWish() {
    const name = nameInput.value.trim();
    const price = Number(priceInput.value);

    if (!name) {
        errorMsg.textContent = 'Ошибка: название не может быть пустым.';
        return;
    }

    if (isNaN(price) || price <= 0) {
        errorMsg.textContent = 'Ошибка: цена должна быть числом больше нуля.';
        return;
    }

    errorMsg.textContent = '';

    const newWish = {
        id: Date.now().toString(),
        name: name,
        price: price,
        isPurchased: false
    };

    wishes.push(newWish);
    saveWishes();
    renderWishes();

    nameInput.value = '';
    priceInput.value = '';
    nameInput.focus();
}

function deleteWish(id) {
    wishes = wishes.filter(wish => wish.id !== id);
    saveWishes();
    renderWishes();
}

function toggleWish(id) {
    const wish = wishes.find(w => w.id === id);
    if (wish) {
        wish.isPurchased = !wish.isPurchased;
        saveWishes();
        renderWishes();
    }
}

addBtn.addEventListener('click', addWish);

nameInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') addWish();
});

priceInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') addWish();
});

wishList.addEventListener('click', (e) => {
    const id = e.target.dataset.id;
    if (!id) return;

    if (e.target.classList.contains('delete-btn')) {
        deleteWish(id);
    } else if (e.target.classList.contains('toggle-btn')) {
        toggleWish(id);
    }
});

renderWishes();