class Book {
    #title;

    constructor(id, title, author, isRead = false) {
        this.id = id;
        this.#title = title;
        this.author = author;
        this.isRead = isRead;
    }

    get title() {
        return this.#title;
    }

    set title(value) {
        const newTitle = value.trim();
        if (newTitle === "") {
            throw new Error("Название книги не может быть пустым");
        }
        this.#title = newTitle;
    }

    toggleRead() {
        this.isRead = !this.isRead;
    }

    toJSON() {
        return {
            id: this.id,
            title: this.title,
            author: this.author,
            isRead: this.isRead
        };
    }
}

const bookForm = document.querySelector("#bookForm");
const titleInput = document.querySelector("#titleInput");
const authorInput = document.querySelector("#authorInput");
const searchInput = document.querySelector("#searchInput");
const filterButtons = document.querySelectorAll(".filter-btn");
const totalCount = document.querySelector("#totalCount");
const readCount = document.querySelector("#readCount");
const unreadCount = document.querySelector("#unreadCount");
const bookList = document.querySelector("#bookList");
const message = document.querySelector("#message");

let books = loadBooks();
let currentFilter = "all";
let searchQuery = "";

updateStats();
renderBooks();

bookForm.addEventListener("submit", function(event) {
    event.preventDefault();

    const title = titleInput.value.trim();
    const author = authorInput.value.trim();

    if (title.length < 2 || author.length < 2) {
        message.textContent = "Название и имя автора должны содержать минимум 2 символа.";
        return;
    }

    message.textContent = "";

    const book = new Book(
        crypto.randomUUID(),
        title,
        author
    );
    books.push(book);
    titleInput.value = "";
    authorInput.value = "";
    saveBooks();
    updateStats();
    renderBooks();
});

searchInput.addEventListener("input", function() {
    searchQuery = searchInput.value.trim().toLowerCase();
    renderBooks();
});

filterButtons.forEach(function(button) {
    button.addEventListener("click", function() {
        filterButtons.forEach(function(btn) {
            btn.classList.remove("active");
        });
        button.classList.add("active");
        currentFilter = button.dataset.filter;
        renderBooks();
    });
});

function saveBooks() {
    localStorage.setItem("books", JSON.stringify(books));
}

function loadBooks() {
    const savedBooks = localStorage.getItem("books");

    if (savedBooks === null) {
        return [];
    }

    const data = JSON.parse(savedBooks);

    return data.map(function(item) {
        return new Book(
            item.id,
            item.title,
            item.author,
            item.isRead
        );
    });
}

function updateStats() {
    const total = books.length;
    const read = books.filter(function(book) {
        return book.isRead;
    }).length;
    const unread = total - read;

    totalCount.textContent = total;
    readCount.textContent = read;
    unreadCount.textContent = unread;
}

function getFilteredBooks() {
    return books.filter(function(book) {
        const matchesSearch = book.title.toLowerCase().includes(searchQuery);
        if (currentFilter === "read") {
            return book.isRead && matchesSearch;
        }
        if (currentFilter === "unread") {
            return !book.isRead && matchesSearch;
        }
        return matchesSearch;
    });
}

function renderBooks() {
    bookList.innerHTML = "";

    const visibleBooks = getFilteredBooks();

    if (books.length === 0) {
        bookList.textContent = "Книг нет...";
        return;
    }

    if (visibleBooks.length === 0) {
        bookList.textContent = "Подходящие книги не найдены.";
        return;
    }

    visibleBooks.forEach(function(book) {
        const card = document.createElement("div");
        card.classList.add("book");

        if (book.isRead) {
            card.classList.add("read");
        }

        const title = document.createElement("h2");
        title.textContent = book.title;
        
        const author = document.createElement("p");
        author.textContent = book.author;

        const status = document.createElement("p");
        if (book.isRead) {
            status.textContent = "Статус: прочитано";
        } else {
            status.textContent = "Статус: не прочитано";
        }

        const readButton = document.createElement("button");
        readButton.type = "button";

        if (book.isRead) {
            readButton.textContent = "Отметить непрочитанной";
        } else {
            readButton.textContent = "Отметить прочитанной";
        }

        readButton.addEventListener("click", function() {
            book.toggleRead();
            saveBooks();
            updateStats();
            renderBooks();
        });

        const deleteButton = document.createElement("button");
        deleteButton.type = "button";
        deleteButton.textContent = "Удалить";

        deleteButton.addEventListener("click", function() {
            books = books.filter(function(item) {
                return item.id !== book.id;
            });
            saveBooks();
            updateStats();
            renderBooks();
        });

        card.append(
            title,
            author,
            status,
            readButton,
            deleteButton
        );
        bookList.append(card);
    });
}
